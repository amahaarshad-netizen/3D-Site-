import type { Config } from 'tailwindcss'
export default { content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'],
 theme:{extend:{colors:{forest:'#0f2a1a',leaf:'#4caf50',mango:'#f5b301',citrus:'#ff8a00',onion:'#8e2a5c',ivory:'#fbf8ef'}}}} satisfies Config
