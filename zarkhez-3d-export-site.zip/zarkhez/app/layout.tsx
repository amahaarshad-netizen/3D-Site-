import './globals.css'
import { Manrope } from 'next/font/google'
import { ProductProvider } from '@/lib/ProductContext'
import Navbar from '@/components/navigation/Navbar'
const sans = Manrope({ subsets: ['latin'], variable: '--font-sans' })
export const metadata = { title: 'Zarkhez | Premium Pakistani Agricultural Exports' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en" className={sans.variable}><body><ProductProvider><Navbar />{children}</ProductProvider></body></html>
}
