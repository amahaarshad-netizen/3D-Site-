'use client'
import { ORDER, PRODUCTS } from '@/lib/products'
import { useProduct } from '@/lib/ProductContext'
export default function ProductSelector() {
  const { product, setProduct } = useProduct()
  return (
    <div className="flex gap-2 rounded-full border border-white/15 bg-black/25 p-1.5 backdrop-blur-md">
      {ORDER.map(id => (
        <button key={id} onClick={() => setProduct(id)} className={`rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-widest transition sm:px-6 ${product === id ? 'text-forest' : 'text-ivory/70 hover:text-ivory'}`}
          style={product === id ? { background: PRODUCTS[id].accent } : undefined}>{id}</button>
      ))}
    </div>
  )
}
