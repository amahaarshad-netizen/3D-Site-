'use client'
import dynamic from 'next/dynamic'
import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { ORDER, PAGES, PRODUCTS, scrollState } from '@/lib/products'
import { useProduct } from '@/lib/ProductContext'
import HeroContent from './HeroContent'
import ProductSelector from './ProductSelector'
const Scene = dynamic(() => import('../three/Scene'), { ssr: false })
export default function HeroSection({ page }: { page: string }) {
  const { product, setProduct } = useProduct()
  const outer = useRef<HTMLDivElement>(null), text = useRef<HTMLDivElement>(null)
  const [ready, setReady] = useState(false), [mobile, setMobile] = useState(false), [reduced, setReduced] = useState(false)
  useEffect(() => { const d = PAGES[page].product; if (d) setProduct(d) }, [page, setProduct])
  useEffect(() => {
    const r = matchMedia('(prefers-reduced-motion: reduce)').matches
    setReduced(r); setMobile(innerWidth < 768); scrollState.p = 0
    if (r) return
    gsap.registerPlugin(ScrollTrigger)
    const ctx = gsap.context(() => {
      ScrollTrigger.create({ trigger: outer.current, start: 'top top', end: 'bottom bottom', scrub: 1, onUpdate: s => { scrollState.p = s.progress } })
      gsap.to(text.current, { y: -90, opacity: 0.1, ease: 'none', scrollTrigger: { trigger: outer.current, start: 'top top', end: '60% top', scrub: true } })
    }, outer)
    return () => ctx.revert()
  }, [])
  return (
    <section ref={outer} style={{ height: reduced ? '100vh' : '260vh' }} className="relative">
      <div className="sticky top-0 h-screen w-full overflow-hidden">
        {ORDER.map(id => <div key={id} className="absolute inset-0 transition-opacity duration-[1400ms]" style={{ background: PRODUCTS[id].bg, opacity: product === id ? 1 : 0 }} />)}
        <div className="absolute inset-0"><Scene active={product} mobile={mobile} reduced={reduced} onReady={() => setReady(true)} /></div>
        <div ref={text} className="relative z-10 flex h-full items-center px-[6%] pb-24 pt-20"><HeroContent page={page} /></div>
        <div className="absolute inset-x-0 bottom-8 z-10 flex justify-center"><ProductSelector /></div>
        <div className={`pointer-events-none absolute inset-0 z-[60] flex items-center justify-center bg-forest transition-opacity duration-1000 ${ready ? 'opacity-0' : 'opacity-100'}`}>
          <span className="animate-pulse text-sm tracking-[0.5em]">ZARKHEZ</span>
        </div>
      </div>
    </section>
  )
}
