'use client'
import Link from 'next/link'
import { AnimatePresence, motion } from 'framer-motion'
import { PAGES, PRODUCTS } from '@/lib/products'
import { useProduct } from '@/lib/ProductContext'
export default function HeroContent({ page }: { page: string }) {
  const cfg = PAGES[page], { product } = useProduct()
  const heading = cfg.heading ?? PRODUCTS[product].heading
  return (
    <div className="max-w-xl">
      <p className="mb-5 text-[11px] font-semibold tracking-[0.3em] sm:text-xs" style={{ color: PRODUCTS[product].accent }}>{cfg.eyebrow}</p>
      <AnimatePresence mode="wait">
        <motion.h1 key={heading} initial={{ opacity: 0, x: -40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 40 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="text-5xl font-light leading-[1.02] tracking-tight sm:text-6xl lg:text-7xl">{heading}</motion.h1>
      </AnimatePresence>
      <p className="mt-6 max-w-md text-base leading-relaxed text-ivory/75">{cfg.desc}</p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link href={cfg.cta[1]} className="rounded-full px-7 py-3.5 text-sm font-semibold text-forest transition hover:scale-105" style={{ background: PRODUCTS[product].accent }}>{cfg.cta[0]}</Link>
        {page === 'home' && <Link href="/contact" className="rounded-full border border-white/30 px-7 py-3.5 text-sm font-semibold backdrop-blur transition hover:bg-white/10">Request a Quote</Link>}
      </div>
    </div>
  )
}
