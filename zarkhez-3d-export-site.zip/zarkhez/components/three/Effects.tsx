'use client'
import * as THREE from 'three'
import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { MeshDistortMaterial } from '@react-three/drei'
import { scrollState } from '@/lib/products'
const UP = new THREE.Vector3(0, 1, 0)
export function Splash({ color, count, speed }: { color: string; count: number; speed: number }) {
  const ref = useRef<THREE.InstancedMesh>(null!), grp = useRef<THREE.Group>(null!), o = useMemo(() => new THREE.Object3D(), [])
  const d = useMemo(() => Array.from({ length: count }, () => {
    const a = Math.random() * 6.283, e = (Math.random() - 0.3) * 1.6
    return { dir: new THREE.Vector3(Math.cos(a) * Math.cos(e), Math.sin(e), Math.sin(a) * Math.cos(e) * 0.5 - 0.2).normalize(), r: 1.3 + Math.random() * 1.9, s: 0.025 + Math.random() * 0.07, ph: Math.random(), st: 1 + Math.random() * 3 }
  }), [count])
  useFrame(({ clock }) => {
    const t = clock.elapsedTime * speed
    d.forEach((q, i) => {
      const u = (t + q.ph) % 1, r = 1 - Math.pow(1 - u, 3), s = q.s * (1 - u * 0.7)
      o.position.copy(q.dir).multiplyScalar(0.7 + q.r * r); o.position.y -= u * u * 0.9; o.position.z -= 0.3
      o.quaternion.setFromUnitVectors(UP, q.dir); o.scale.set(s, s * (1 + q.st * (1 - u)), s); o.updateMatrix(); ref.current.setMatrixAt(i, o.matrix)
    })
    ref.current.instanceMatrix.needsUpdate = true
    grp.current.position.z = -scrollState.p * 1.2; grp.current.scale.setScalar(1 + scrollState.p * 0.35)
  })
  return (
    <group ref={grp}>
      <instancedMesh ref={ref} args={[undefined, undefined, count]}><sphereGeometry args={[1, 10, 10]} />
        <meshPhysicalMaterial color={color} roughness={0.05} clearcoat={1} transparent opacity={0.85} envMapIntensity={2} /></instancedMesh>
      <mesh position={[0, 0, -1]} scale={[1.7, 1.7, 0.2]}><sphereGeometry args={[1, 40, 40]} />
        <MeshDistortMaterial color={color} distort={0.5} speed={speed * 5} transparent opacity={0.4} roughness={0.1} /></mesh>
    </group>
  )
}
export function Ambient({ color, count, factor }: { color: string; count: number; factor: number }) {
  const g = useRef<THREE.Points>(null!)
  const pos = useMemo(() => Float32Array.from({ length: count * 3 }, (_, i) => (Math.random() - 0.5) * (i % 3 === 2 ? 5 : 9)), [count])
  useFrame(({ clock }) => { g.current.rotation.y = clock.elapsedTime * 0.03 * factor; g.current.position.x = -scrollState.p * 2.5 * factor; g.current.position.y = scrollState.p * 1.5 * factor })
  return <points ref={g}><bufferGeometry><bufferAttribute attach="attributes-position" array={pos} count={count} itemSize={3} /></bufferGeometry><pointsMaterial color={color} size={0.045} transparent opacity={0.75} sizeAttenuation depthWrite={false} /></points>
}
export function Floaters({ kind, count, speed }: { kind: 'leaf' | 'skin'; count: number; speed: number }) {
  const refs = useRef<THREE.Mesh[]>([])
  useFrame(({ clock }) => {
    const t = clock.elapsedTime * speed
    refs.current.forEach((m, i) => { if (!m) return; const a = t * 0.35 + i * (6.283 / count)
      m.position.set(Math.cos(a) * 2.1, Math.sin(t * 0.8 + i * 2) * 0.9 + 0.3, Math.sin(a) * 1.1 - 0.3); m.rotation.set(t * 0.5 + i, t * 0.7, i) })
  })
  return <>{Array.from({ length: count }, (_, i) => (
    <mesh key={i} ref={el => { if (el) refs.current[i] = el }} scale={kind === 'leaf' ? [0.7, 0.04, 0.22] : 0.45}>
      {kind === 'leaf' ? <sphereGeometry args={[1, 16, 8]} /> : <sphereGeometry args={[1, 16, 12, 0, 1.3, 0.5, 1.1]} />}
      {kind === 'leaf' ? <meshStandardMaterial color="#2f7d32" roughness={0.5} /> : <meshStandardMaterial color="#b8864a" roughness={0.8} side={THREE.DoubleSide} transparent opacity={0.8} />}
    </mesh>))}</>
}
