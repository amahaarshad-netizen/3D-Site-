'use client'
import * as THREE from 'three'
import { ReactNode, useRef } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, ContactShadows } from '@react-three/drei'
import { ORDER, PRODUCTS, ProductId, scrollState } from '@/lib/products'
import { Mango, Orange, Onion } from './Models'
import { Splash, Ambient, Floaters } from './Effects'
const M = THREE.MathUtils
function Reveal({ id, active, speed, children }: { id: ProductId; active: ProductId; speed: number; children: ReactNode }) {
  const g = useRef<THREE.Group>(null!), p = useRef(0), t = useRef(0), vw = useThree(s => s.viewport.width)
  useFrame((_, dt) => {
    p.current = M.damp(p.current, active === id ? 1 : 0, 2.4, dt); t.current += dt * speed
    const e = p.current, s = scrollState.p, base = vw > 7 ? 2.1 : 0
    g.current.visible = e > 0.01; g.current.scale.setScalar(0.001 + e)
    g.current.position.set(base * (1 - s * 0.9), (1 - e) * -3 + Math.sin(t.current * 0.9) * 0.12, 0)
    g.current.rotation.set(0.1 + s * 0.6, t.current * 0.45 + s * Math.PI * 2 + (1 - e) * 6, 0)
  })
  return <group ref={g}>{children}</group>
}
function Rig({ active }: { active: ProductId }) {
  const key = useRef<THREE.SpotLight>(null!), col = useRef(new THREE.Color())
  useFrame(({ camera }, dt) => {
    camera.position.z = M.damp(camera.position.z, 7 - Math.sin(scrollState.p * Math.PI) * 2.2, 3, dt)
    camera.position.y = M.damp(camera.position.y, scrollState.p * 0.8, 3, dt); camera.lookAt(0, 0, 0)
    key.current.color.lerp(col.current.set(PRODUCTS[active].light), dt * 2.5)
  })
  return <spotLight ref={key} position={[4, 6, 5]} intensity={90} angle={0.5} penumbra={1} castShadow />
}
export default function Scene({ active, mobile, reduced, onReady }: { active: ProductId; mobile: boolean; reduced: boolean; onReady: () => void }) {
  const speed = reduced ? 0.15 : 1, n = mobile ? 50 : 140, amb = mobile ? 60 : 200
  const models: Record<ProductId, ReactNode> = { mango: <Mango />, orange: <Orange />, onion: <Onion /> }
  return (
    <Canvas shadows={!mobile} dpr={mobile ? [1, 1.5] : [1, 2]} camera={{ position: [0, 0, 7], fov: 38 }} gl={{ alpha: true, antialias: !mobile, toneMapping: THREE.ACESFilmicToneMapping }}
      onCreated={() => setTimeout(onReady, 600)}>
      <ambientLight intensity={0.35} />
      <Rig active={active} />
      <Environment resolution={256}><group rotation={[0, 0.6, 0]}>
        <Lightformer form="rect" intensity={4} position={[0, 5, -4]} scale={[10, 4, 1]} />
        <Lightformer form="rect" intensity={2} position={[-5, 1, 2]} scale={[3, 6, 1]} color="#fff3d6" />
        <Lightformer form="ring" intensity={3} position={[4, 0, 3]} scale={3} />
      </group></Environment>
      {ORDER.map(id => (
        <Reveal key={id} id={id} active={active} speed={speed}>
          {models[id]}
          <Splash color={PRODUCTS[id].juice} count={n} speed={0.22 * speed} />
          <Ambient color={PRODUCTS[id].light} count={amb} factor={id === 'onion' ? 0.6 : 1} />
          {id === 'mango' && <Floaters kind="leaf" count={4} speed={speed} />}
          {id === 'onion' && <Floaters kind="skin" count={5} speed={speed} />}
          {id === 'orange' && <Floaters kind="leaf" count={2} speed={speed} />}
        </Reveal>
      ))}
      {!mobile && <ContactShadows position={[2, -2.3, 0]} opacity={0.35} scale={9} blur={2.6} far={4} />}
    </Canvas>
  )
}
