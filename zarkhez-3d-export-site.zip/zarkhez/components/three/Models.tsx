'use client'
import * as THREE from 'three'
import { useMemo } from 'react'
const tex = (draw: (g: CanvasRenderingContext2D) => void, w = 256, h = 256, rep: [number, number] = [2, 2]) => {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d')!)
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...rep); t.anisotropy = 4; return t
}
const specks = (base: string, dot: string, n: number, r: number) => (g: CanvasRenderingContext2D) => {
  g.fillStyle = base; g.fillRect(0, 0, 256, 256); g.fillStyle = dot
  for (let i = 0; i < n; i++) { g.globalAlpha = Math.random() * 0.6; g.beginPath(); g.arc(Math.random() * 256, Math.random() * 256, Math.random() * r + 0.6, 0, 7); g.fill() }
}
const smooth = (a: number, b: number, x: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t) }

export function Mango() {
  const { geo, bump } = useMemo(() => {
    const g = new THREE.SphereGeometry(1, 72, 72), p = g.attributes.position, col = new Float32Array(p.count * 3)
    const Y = new THREE.Color('#f2b705'), O = new THREE.Color('#ee8a0c'), R = new THREE.Color('#c42f1b'), G = new THREE.Color('#8fa832'), c = new THREE.Color()
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i), blush = smooth(-0.2, 0.9, x) * (0.5 + 0.5 * Math.sin(y * 2 + z))
      c.copy(Y).lerp(O, blush * 0.8).lerp(R, blush * blush * 0.55).lerp(G, smooth(0.6, 1, y) * 0.5 + (Math.random() - 0.5) * 0.04)
      col.set([c.r, c.g, c.b], i * 3)
      p.setXYZ(i, x * 0.74 * (1 - 0.14 * y) + 0.14 * (1 - y * y), y * 1.08, z * 0.62)
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.computeVertexNormals()
    return { geo: g, bump: tex(specks('#999', '#000', 900, 1.6), 256, 256, [3, 3]) }
  }, [])
  return (
    <group rotation={[0, 0, -0.35]} scale={1.15}>
      <mesh geometry={geo} castShadow><meshPhysicalMaterial vertexColors bumpMap={bump} bumpScale={0.6} roughness={0.42} clearcoat={0.5} clearcoatRoughness={0.35} sheen={0.4} /></mesh>
      <mesh position={[0.02, 1.1, 0]} rotation={[0, 0, 0.2]}><cylinderGeometry args={[0.04, 0.07, 0.22, 10]} /><meshStandardMaterial color="#5b4a1c" roughness={0.8} /></mesh>
    </group>
  )
}
export function Orange() {
  const bump = useMemo(() => tex(specks('#aaa', '#000', 2200, 1.4), 256, 256, [4, 4]), [])
  return (
    <group scale={1.15}>
      <mesh scale={[1, 0.96, 1]} castShadow><sphereGeometry args={[1, 72, 72]} />
        <meshPhysicalMaterial color="#ff8a00" bumpMap={bump} bumpScale={1.2} roughness={0.38} clearcoat={0.45} clearcoatRoughness={0.4} sheen={0.5} sheenColor="#ffd08a" /></mesh>
      <mesh position={[0, 0.95, 0]} scale={[1, 0.3, 1]}><sphereGeometry args={[0.13, 16, 12]} /><meshStandardMaterial color="#4d6b1f" roughness={0.7} /></mesh>
    </group>
  )
}
export function Onion() {
  const { geo, map } = useMemo(() => {
    const pts = [[0.001, -0.95], [0.3, -0.92], [0.72, -0.68], [0.98, -0.1], [0.9, 0.45], [0.55, 0.9], [0.25, 1.25], [0.11, 1.55], [0.08, 1.7]].map(([x, y]) => new THREE.Vector2(x, y))
    const m = tex(g => {
      for (let x = 0; x < 512; x++) { const t = Math.sin(x * 0.19) * 0.5 + 0.5, n = Math.random() * 0.25
        g.fillStyle = `hsl(${335 + t * 12},${55 + t * 20}%,${28 + t * 28 + n * 12}%)`; g.fillRect(x, 0, 1, 256) }
    }, 512, 256, [1, 1])
    return { geo: new THREE.LatheGeometry(pts, 96), map: m }
  }, [])
  return (
    <group scale={0.95} position={[0, -0.35, 0]}>
      <mesh geometry={geo} castShadow><meshPhysicalMaterial map={map} roughness={0.3} clearcoat={0.85} clearcoatRoughness={0.2} sheen={0.7} sheenColor="#ffb6d6" /></mesh>
      <mesh position={[0, 1.78, 0]}><coneGeometry args={[0.12, 0.32, 10]} /><meshStandardMaterial color="#a8742a" roughness={0.9} /></mesh>
      <mesh position={[0, -1, 0]} rotation={[Math.PI, 0, 0]}><coneGeometry args={[0.22, 0.2, 14]} /><meshStandardMaterial color="#7b5320" roughness={1} /></mesh>
    </group>
  )
}
