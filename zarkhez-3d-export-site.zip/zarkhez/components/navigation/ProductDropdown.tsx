'use client'
import { motion } from 'framer-motion'
import { ORDER, PRODUCTS, ProductId } from '@/lib/products'
export default function ProductDropdown({ onPick, inline }: { onPick: (p: ProductId) => void; inline?: boolean }) {
  return (
    <motion.ul initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
      className={inline ? 'mt-2 space-y-1 pl-4' : 'absolute left-1/2 top-full mt-4 w-56 -translate-x-1/2 rounded-2xl border border-white/15 bg-black/40 p-2 backdrop-blur-xl'}>
      {ORDER.map(id => (
        <li key={id}><button onClick={() => onPick(id)} className="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-left text-sm hover:bg-white/10">
          <span className="h-2 w-2 rounded-full" style={{ background: PRODUCTS[id].accent }} />{PRODUCTS[id].label}</button></li>
      ))}
    </motion.ul>
  )
}
