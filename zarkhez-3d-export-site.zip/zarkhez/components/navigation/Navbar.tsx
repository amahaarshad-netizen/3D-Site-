'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState } from 'react'
import { AnimatePresence } from 'framer-motion'
import ProductDropdown from './ProductDropdown'
import { useProduct } from '@/lib/ProductContext'
import type { ProductId } from '@/lib/products'
const links = [['Home', '/'], ['About Us', '/about'], ['Quality & Certifications', '/quality'], ['Contact Us', '/contact']]
export default function Navbar() {
  const path = usePathname(), router = useRouter(), { setProduct } = useProduct()
  const [dd, setDd] = useState(false), [open, setOpen] = useState(false)
  const pick = (id: ProductId) => { setProduct(id); setDd(false); setOpen(false); if (path !== '/' && path !== '/products') router.push('/products') }
  const cls = (h: string) => `relative py-1 text-sm tracking-wide transition after:absolute after:-bottom-0.5 after:left-0 after:h-px after:bg-ivory after:transition-all hover:after:w-full ${path === h ? 'after:w-full' : 'text-ivory/75 after:w-0'}`
  return (
    <header className="fixed inset-x-0 top-4 z-50 mx-auto w-[min(1200px,94%)]">
      <nav className="flex items-center justify-between rounded-full border border-white/15 bg-white/5 px-5 py-3 shadow-2xl backdrop-blur-xl">
        <Link href="/" className="text-lg font-semibold tracking-[0.28em]">ZARK<span className="text-mango">HEZ</span></Link>
        <ul className="hidden items-center gap-8 lg:flex">
          {links.slice(0, 2).map(([n, h]) => <li key={h}><Link href={h} className={cls(h)}>{n}</Link></li>)}
          <li className="relative" onMouseEnter={() => setDd(true)} onMouseLeave={() => setDd(false)}>
            <Link href="/products" className={cls('/products')}>Products ▾</Link>
            <AnimatePresence>{dd && <ProductDropdown onPick={pick} />}</AnimatePresence>
          </li>
          {links.slice(2).map(([n, h]) => <li key={h}><Link href={h} className={cls(h)}>{n}</Link></li>)}
        </ul>
        <div className="flex items-center gap-3">
          <Link href="/contact" className="hidden rounded-full bg-ivory px-5 py-2 text-sm font-semibold text-forest transition hover:bg-mango sm:block">Request a Quote</Link>
          <button aria-label="Menu" className="lg:hidden" onClick={() => setOpen(!open)}>{open ? '✕' : '☰'}</button>
        </div>
      </nav>
      {open && (
        <div className="mt-2 rounded-3xl border border-white/15 bg-black/60 p-5 backdrop-blur-xl lg:hidden">
          <ul className="space-y-3">
            {links.slice(0, 2).map(([n, h]) => <li key={h}><Link href={h} onClick={() => setOpen(false)}>{n}</Link></li>)}
            <li><button onClick={() => setDd(!dd)}>Products ▾</button>{dd && <ProductDropdown inline onPick={pick} />}</li>
            {links.slice(2).map(([n, h]) => <li key={h}><Link href={h} onClick={() => setOpen(false)}>{n}</Link></li>)}
            <li><Link href="/contact" onClick={() => setOpen(false)} className="font-semibold text-mango">Request a Quote →</Link></li>
          </ul>
        </div>
      )}
    </header>
  )
}
