# Zarkhez 3D export hero
npm install && npm run dev -> http://localhost:3000
Models are procedural (components/three/Models.tsx); swap for drei useGLTF to use GLB files.
