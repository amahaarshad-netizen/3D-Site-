export type ProductId = 'mango' | 'orange' | 'onion'
export const PRODUCTS: Record<ProductId, { label: string; heading: string; juice: string; light: string; accent: string; bg: string }> = {
  mango: { label: 'Fresh Mangoes', heading: 'The Taste of Pakistan.', juice: '#ffb300', light: '#ffd27a', accent: '#f5b301',
    bg: 'radial-gradient(70% 80% at 72% 50%,#e8a31766,transparent 70%),linear-gradient(135deg,#0f2a1a,#2d3b0f 60%,#5a3d08)' },
  orange: { label: 'Fresh Oranges', heading: 'Pure Citrus. Premium Quality.', juice: '#ff8a00', light: '#ffb066', accent: '#ff8a00',
    bg: 'radial-gradient(70% 80% at 72% 50%,#ff8a0070,transparent 70%),linear-gradient(135deg,#1c1206,#5c2a05 60%,#8a3d00)' },
  onion: { label: 'Fresh Onions', heading: 'Freshness Rooted in Quality.', juice: '#d86a9a', light: '#e9a6c6', accent: '#d0629a',
    bg: 'radial-gradient(70% 80% at 72% 50%,#8e2a5c66,transparent 70%),linear-gradient(135deg,#0f2a1a,#2a1230 60%,#1a2a14)' },
}
export const ORDER: ProductId[] = ['mango', 'orange', 'onion']
export const scrollState = { p: 0 }
export type PageCfg = { eyebrow: string; heading?: string; desc: string; product?: ProductId; cta: [string, string] }
export const PAGES: Record<string, PageCfg> = {
  home: { eyebrow: 'PREMIUM PAKISTANI AGRICULTURAL EXPORTS', desc: 'Delivering premium-quality Pakistani mangoes, oranges, and fresh vegetables to international markets with excellence, quality, and trust.', product: 'mango', cta: ['Explore Our Products', '/products'] },
  about: { eyebrow: 'ABOUT ZARKHEZ', heading: 'Grown with Heritage. Shipped with Pride.', desc: 'From the orchards of Sindh and Punjab to shelves across the world, we connect growers and global markets with integrity.', product: 'mango', cta: ['Our Story', '/about'] },
  products: { eyebrow: 'OUR PRODUCE', desc: 'Choose a harvest below and watch it come alive: mangoes, oranges and onions, selected at peak freshness.', cta: ['Request Samples', '/contact'] },
  quality: { eyebrow: 'QUALITY & CERTIFICATIONS', heading: 'Quality You Can Trace.', desc: 'Rigorous grading, cold-chain logistics and international standards, from farm gate to port.', product: 'orange', cta: ['View Standards', '/quality'] },
  contact: { eyebrow: 'CONTACT US', heading: "Let's Bring Pakistan to Your Market.", desc: 'Tell us your volumes, destination and season. Our export team responds within one business day.', product: 'onion', cta: ['Start a Conversation', '/contact'] },
}
