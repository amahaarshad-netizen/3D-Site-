'use client'
import { createContext, useContext, useState, ReactNode } from 'react'
import type { ProductId } from './products'
const Ctx = createContext<{ product: ProductId; setProduct: (p: ProductId) => void }>({ product: 'mango', setProduct: () => {} })
export const ProductProvider = ({ children }: { children: ReactNode }) => {
  const [product, setProduct] = useState<ProductId>('mango')
  return <Ctx.Provider value={{ product, setProduct }}>{children}</Ctx.Provider>
}
export const useProduct = () => useContext(Ctx)
